import pygame, sys, json
from pathlib import Path
from PIL import Image, ImageSequence

# ---------- CONFIG ----------
SCREEN_W, SCREEN_H = 900, 520
FPS = 60
ASSETS_DIR = Path("assets")
IMAGES_DIR = ASSETS_DIR / "images"
MUSIC_DIR = ASSETS_DIR / "music"
TOTAL_LEVELS = 15
PLAYER_SPEED = 4
PLAYER_SCALE = 2
FONT_NAME = None  # default font
HEART_IMG = None  # optional: hearts asset path

# --- MÚSICAS POR ESCENA ---
MUSIC_TRACKS = {
    "start": "start_theme.mp3",   # música del inicio
    "level1": "mus1.mp3",
    "level2": "mus2.mp3",
    "level3": "mus3.mp3",
    "level4": "mus4.mp3",
    "level5": "mus5.mp3",
    "level6": "mus6.mp3",
    "level7": "mus7.mp3",
    "level8": "mus8.mp3",
    "level9": "mus9.mp3",
    "level10": "mus10.mp3",
    "level11": "mus11.mp3",
    "level12": "mus12.mp3",
    "level13": "mus13.mp3",
    "level14": "mus14.mp3",
    "level15": "mus15.mp3",
}

# ---------- LEVEL DATA ----------
with open("levels/levels.json", "r", encoding="utf-8") as f:
    LEVELS = json.load(f)

# ---------- RESOURCE MANAGER ----------
# Clase encargada de gestionar recursos (imágenes, sonidos, etc.) en un juego
class ResourceManager:

    # Constructor de la clase
    def __init__(self, assets_dir=ASSETS_DIR, images_dir=IMAGES_DIR, music_dir=MUSIC_DIR):
        # Guarda las rutas principales como objetos Path (más fáciles de manejar)
        self.assets_dir = Path(assets_dir)
        self.images_dir = Path(images_dir)
        self.music_dir = Path(music_dir)

        # Diccionarios para almacenar los recursos cargados
        # La estructura es: { clave: (recurso, referencias) }
        self.images = {}
        self.sounds = {}

    # -------------------------------------------------------------
    # Método para buscar un archivo en las carpetas de assets
    def path(self, fname):
        """Busca un archivo en images/, music/ o la raíz de assets/."""
        # Construye posibles rutas del archivo
        p_img = self.images_dir / fname
        p_mus = self.music_dir / fname
        p_root = self.assets_dir / fname

        # Devuelve la primera ruta donde el archivo exista
        if p_img.exists():
            return p_img
        elif p_mus.exists():
            return p_mus
        else:
            return p_root

    # -------------------------------------------------------------
    # Cargar una imagen y asociarla a una clave
    def load_image(self, key, fname, colorkey=None):
        # Si ya está cargada, solo aumenta el contador de referencias
        if key in self.images:
            surf, r = self.images[key]
            self.images[key] = (surf, r + 1)
            return surf

        # Busca la ruta del archivo de imagen
        p = self.path(fname)

        # Si el archivo existe, lo carga con pygame
        if p.exists():
            surf = pygame.image.load(str(p)).convert_alpha()  # Carga con transparencia
        else:
            surf = None  # Si no existe, asigna None

        # Guarda la imagen con 1 referencia inicial
        self.images[key] = (surf, 1)
        return surf

    # -------------------------------------------------------------
    # Liberar una imagen (cuando ya no se necesita)
    def unload_image(self, key):
        if key in self.images:
            surf, r = self.images[key]
            # Si no quedan referencias, elimina la imagen del diccionario
            if r <= 1:
                del self.images[key]
            else:
                # Si todavía se usa en otro lugar, solo reduce el contador
                self.images[key] = (surf, r - 1)

    # -------------------------------------------------------------
    # Cargar un sonido y asociarlo a una clave
    def load_sound(self, key, fname):
        # Si ya está cargado, aumenta la referencia
        if key in self.sounds:
            s, r = self.sounds[key]
            self.sounds[key] = (s, r + 1)
            return s

        # Busca la ruta del archivo de sonido
        p = self.path(fname)

        # Si existe, lo carga con pygame.mixer.Sound
        if p.exists():
            s = pygame.mixer.Sound(str(p))
        else:
            s = None

        # Guarda el sonido con 1 referencia inicial
        self.sounds[key] = (s, 1)
        return s

    # -------------------------------------------------------------
    # Liberar un sonido (cuando ya no se necesita)
    def unload_sound(self, key):
        if key in self.sounds:
            s, r = self.sounds[key]
            # Si ya no se usa más, detenerlo y eliminarlo
            if r <= 1:
                if s:
                    s.stop()  # Detiene el sonido si está reproduciéndose
                del self.sounds[key]
            else:
                # Si todavía hay referencias, solo disminuir el contador
                self.sounds[key] = (s, r - 1)

    # -------------------------------------------------------------
    # Cargar los recursos asociados a un nivel del juego
    def load_level_assets(self, level):
        loaded = {}  # Diccionario temporal con los recursos cargados

        # Fondo del nivel
        bg_file = level.get("bg")
        if bg_file:
            loaded["bg"] = self.load_image(f"bg_{level['nivel']}", bg_file)

        # Sprite del NPC (personaje no jugable)
        loaded["npc"] = self.load_image(f"npc_{level['nivel']}", "npc.png")

        # Sprite de la isla u objeto principal del nivel
        loaded["illa"] = self.load_image(f"illa_{level['nivel']}", f"illa_{level['nivel']}.png")

        return loaded  # Devuelve todos los recursos cargados del nivel

    # -------------------------------------------------------------
    # Liberar los recursos asociados a un nivel
    def unload_level_assets(self, level):
        # Libera cada imagen cargada para ese nivel
        self.unload_image(f"bg_{level['nivel']}")
        self.unload_image(f"npc_{level['nivel']}")
        self.unload_image(f"illa_{level['nivel']}")


# ---------- UTILITIES ----------
# Función que crea una superficie de texto en Pygame
def make_text_surface(text, font, color=(255,255,255)):
    # 'font.render' crea una imagen (Surface) con el texto indicado
    # Parámetros:
    #   text  → texto que se va a mostrar
    #   True  → suavizado (antialias)
    #   color → color del texto (por defecto blanco)
    return font.render(text, True, color)


# -------------------------------------------------------------
# Función para dibujar un botón con texto en una superficie (pantalla o menú)
def draw_button(surface, rect, text, font, color_bg=(200,140,50), color_text=(255,255,255)):
    # Dibuja un rectángulo ligeramente más grande (borde externo o sombra)
    pygame.draw.rect(surface, (30,30,30), rect.inflate(4,4))

    # Dibuja el rectángulo principal del botón con el color de fondo indicado
    pygame.draw.rect(surface, color_bg, rect)

    # Renderiza el texto del botón con la fuente y color especificados
    txt = font.render(text, True, color_text)

    # Obtiene un rectángulo del texto y lo centra dentro del botón
    tr = txt.get_rect(center=rect.center)

    # Dibuja (blitea) el texto sobre el botón
    surface.blit(txt, tr)


# ---------- PLAYER SPRITE ----------
# Clase Player: representa al jugador del juego
# Hereda de pygame.sprite.Sprite para poder usarse en grupos de sprites
class Player(pygame.sprite.Sprite):

    # -------------------------------------------------------------
    # Constructor de la clase
    def __init__(self, resman, pos=(50, SCREEN_H-150)):
        # Llama al constructor de la clase padre (Sprite)
        super().__init__()

        # Guarda una referencia al administrador de recursos (ResourceManager)
        self.resman = resman

        # Carga la imagen de "quieto" (idle) desde los recursos
        idle = resman.load_image("player_idle", "player_idle.png")

        # ---------------------------------------------------------
        # Carga animaciones de caminar hacia la derecha
        walk_r = []
        gif_path = resman.path("player_walk_right.gif")  # Busca el GIF
        if gif_path.exists():
            gif = Image.open(gif_path)  # Abre el GIF con PIL (Pillow)
            # Itera sobre cada frame del GIF
            for frame in ImageSequence.Iterator(gif):
                frame = frame.convert("RGBA")  # Asegura canal alfa
                mode, size, data = frame.mode, frame.size, frame.tobytes()
                # Convierte el frame en una Surface de Pygame
                walk_r.append(pygame.image.fromstring(data, size, mode))

        # ---------------------------------------------------------
        # Carga animaciones de caminar hacia la izquierda
        walk_l = []
        gif_path_left = resman.path("player_walk_left.gif")
        if gif_path_left.exists():
            gif = Image.open(gif_path_left)
            for frame in ImageSequence.Iterator(gif):
                frame = frame.convert("RGBA")
                mode, size, data = frame.mode, frame.size, frame.tobytes()
                walk_l.append(pygame.image.fromstring(data, size, mode))
        elif walk_r:
            # Si no existe el GIF de izquierda, crea uno invirtiendo los frames derechos
            for surf in walk_r:
                walk_l.append(pygame.transform.flip(surf, True, False))

        # ---------------------------------------------------------
        # Si no existe la imagen "idle", crea un marcador de posición (un rectángulo amarillo)
        if idle is None:
            idle = pygame.Surface((40, 56), pygame.SRCALPHA)
            idle.fill((255, 200, 0))  # Relleno amarillo
            pygame.draw.rect(idle, (0, 0, 0), idle.get_rect(), 2)  # Borde negro

        # ---------------------------------------------------------
        # Si no existen animaciones de caminar, crea dos cuadros de colores para simular el movimiento
        if not walk_r:
            w1 = pygame.Surface((40, 56), pygame.SRCALPHA); w1.fill((255,190,0))
            w2 = pygame.Surface((40, 56), pygame.SRCALPHA); w2.fill((255,170,0))
            walk_r = [w1, w2]
            # Crea las versiones reflejadas para la izquierda
            walk_l = [
                pygame.transform.flip(w1, True, False),
                pygame.transform.flip(w2, True, False)
            ]

        # ---------------------------------------------------------
        # Guarda las listas de imágenes para las distintas animaciones
        self.frames_idle = [idle]      # Quieto
        self.frames_right = walk_r     # Caminando a la derecha
        self.frames_left = walk_l      # Caminando a la izquierda

        # Estado inicial del jugador
        self.facing = "right"          # Dirección a la que mira
        self.anim_index = 0            # Índice del cuadro actual
        self.anim_timer = 0            # Temporizador de animación
        self.anim_speed = 150          # Tiempo (ms) entre frames
        self.image = self.frames_idle[0]  # Imagen inicial mostrada
        self.rect = self.image.get_rect() # Rectángulo de colisión
        self.rect.topleft = pos           # Posición inicial
        self.speed = PLAYER_SPEED         # Velocidad de movimiento

    # -------------------------------------------------------------
    # Método update: se llama cada frame del juego
    # 'dt' = tiempo transcurrido desde el último frame
    # 'keys' = teclas presionadas
    def update(self, dt, keys):
        moving = False  # Indica si el jugador se está moviendo

        # Movimiento a la izquierda
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.rect.x -= self.speed   # Mueve el rectángulo hacia la izquierda
            self.facing = "left"        # Cambia la dirección
            moving = True

        # Movimiento a la derecha
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.rect.x += self.speed   # Mueve hacia la derecha
            self.facing = "right"
            moving = True

        # Mantiene al jugador dentro de los límites de la pantalla
        self.rect.left = max(0, self.rect.left)
        self.rect.right = min(SCREEN_W, self.rect.right)

        # Incrementa el temporizador de animación
        self.anim_timer += dt

        # ---------------------------------------------------------
        # Si el jugador se está moviendo, actualiza la animación
        if moving:
            # Intenta reproducir sonido de caminar (si está cargado)
            snd_data = self.resman.sounds.get("walk")
            if snd_data:
                snd, _ = snd_data
                # Reproduce si no hay otro sonido corto en curso
                if snd and not pygame.mixer.get_busy():
                    snd.play()

            # Cambia al siguiente frame de animación cada cierto tiempo
            if self.anim_timer >= self.anim_speed:
                self.anim_timer = 0
                self.anim_index = (self.anim_index + 1) % len(self.frames_right)

            # Selecciona el frame correspondiente según la dirección
            if self.facing == "right":
                self.image = self.frames_right[self.anim_index]
            else:
                self.image = self.frames_left[self.anim_index]

        # ---------------------------------------------------------
        # Si no se está moviendo, muestra el frame "idle"
        else:
            self.image = self.frames_idle[0]

# ---------- NPC ----------
# Clase NPC: representa a un personaje no jugable del juego
# (Non-Player Character)
class NPC(pygame.sprite.Sprite):

    # -------------------------------------------------------------
    # Constructor: recibe el administrador de recursos (resman)
    # y la posición inicial (pos)
    def __init__(self, resman, pos):
        # Llama al constructor de la clase base Sprite
        super().__init__()

        # Intenta cargar la imagen del NPC desde los recursos
        surf = resman.load_image("npc_generic", "npc.png")

        # Si no se encuentra la imagen, crea una de reemplazo (marcador de posición)
        if surf is None:
            # Crea una superficie vacía de 48x72 píxeles con transparencia
            surf = pygame.Surface((48, 72), pygame.SRCALPHA)
            # Rellena con un color marrón claro (color base del NPC)
            surf.fill((200, 100, 80))
            # Dibuja un borde negro alrededor
            pygame.draw.rect(surf, (0, 0, 0), surf.get_rect(), 2)

        # Guarda la imagen final del NPC (ya sea cargada o generada)
        self.image = surf

        # Obtiene el rectángulo que representa su posición y tamaño en pantalla
        # y centra al NPC en la posición dada (pos)
        self.rect = self.image.get_rect(center=pos)

# ---------- GAME SCENES / STATES ----------
# Clase base para todas las escenas del juego (menú, niveles, etc.)
# Define la estructura general que cada escena debe tener
class SceneBase:
    def __init__(self, game):
        # Guarda una referencia al objeto principal del juego
        # (normalmente contiene la ventana, recursos, etc.)
        self.game = game

    # -------------------------------------------------------------
    # Métodos que deben ser sobreescritos por las clases hijas
    # -------------------------------------------------------------

    # Se ejecuta al iniciar la escena (opcional en clases hijas)
    def start(self): 
        pass

    # Maneja eventos del teclado, ratón, etc.
    def handle_event(self, event): 
        pass

    # Actualiza la lógica interna de la escena (movimiento, tiempo, etc.)
    def update(self, dt): 
        pass

    # Dibuja el contenido de la escena en pantalla
    def render(self, surf): 
        pass


# -------------------------------------------------------------
# Escena de inicio o menú principal del juego
# -------------------------------------------------------------
class StartScene(SceneBase):
    def __init__(self, game):
        # Llama al constructor de la clase base
        super().__init__(game)

        # Carga la imagen de fondo del menú (si existe)
        # "resman" es el administrador de recursos del juego
        self.bg = self.game.resman.load_image("start_bg", "start_bg.png")

        # Define el área invisible del botón "Iniciar"
        # (centrado horizontalmente, cerca de la parte inferior de la pantalla)
        self.btn_rect = pygame.Rect(
            (SCREEN_W // 2 - 160, SCREEN_H - 140, 320, 70)
        )

    # -------------------------------------------------------------
    # Manejo de eventos de la escena
    # -------------------------------------------------------------
    def handle_event(self, event):
        # Si el jugador hace clic con el botón izquierdo del ratón...
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # ...y el clic ocurre dentro del área invisible del botón:
            if self.btn_rect.collidepoint(event.pos):
                # Inicia el primer nivel del juego
                self.game.start_level(0)

        # También permite iniciar el juego presionando la tecla Enter
        if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
            self.game.start_level(0)

    # -------------------------------------------------------------
    # Dibujo de la escena en pantalla
    # -------------------------------------------------------------
    def render(self, surf):
        # Si existe la imagen de fondo, se dibuja escalada al tamaño de la pantalla
        if self.bg:
            surf.blit(
                pygame.transform.smoothscale(self.bg, (SCREEN_W, SCREEN_H)),
                (0, 0)
            )
        else:
            # Si no hay fondo, se rellena la pantalla con un color de respaldo
            surf.fill((60, 160, 200))

        # (Opcional, solo para pruebas)
        # Dibuja el contorno del área clickeable en rojo para verificar su posición
        # pygame.draw.rect(surf, (255, 0, 0), self.btn_rect, 2)

# ===========================================================
# Escena del nivel del juego (preguntas + movimiento)
# ===========================================================
class LevelScene(SceneBase):
    def __init__(self, game, level_index):
        super().__init__(game)
        self.level_index = level_index
        self.level_data = LEVELS[level_index]
        self.assets = {}
        self.player = None
        self.npc = None
        self.illa_img = None
        self.font = pygame.font.SysFont(FONT_NAME, 20)
        self.bigfont = pygame.font.SysFont(FONT_NAME, 28, bold=True)
        self.question_active = False
        self.current_question = None
        self.message = ""
        self.prompt_cooldown = 0

    # -------------------------------------------------------------
    # Inicialización de los elementos del nivel
    # -------------------------------------------------------------
    def start(self):
        # Carga recursos del nivel
        self.assets = self.game.resman.load_level_assets(self.level_data)

        # 🧍 Crear jugador
        self.player = Player(self.game.resman, pos=(40, SCREEN_H - 150))

        # 🧠 Determinar NPC según el número del nivel
        npc_num = (self.level_index % 15) + 1
        npc_image = f"npc{npc_num}.png"
        npc_pos = (SCREEN_W // 2, SCREEN_H - 150)

        # Cargar imagen del NPC
        npc_surface = self.game.resman.load_image(f"npc{npc_num}", f"images/{npc_image}")
        self.npc = NPC(self.game.resman, npc_pos)
        if npc_surface:
            self.npc.image = pygame.transform.smoothscale(npc_surface, (100, 120))
            self.npc.rect = self.npc.image.get_rect(midbottom=npc_pos)

        # 🏝️ Cargar imagen de la Illa del nivel
        illa_num = (self.level_index % 15) + 1
        illa_image = f"Illa{illa_num}.png"
        self.illa_img = self.game.resman.load_image(f"illa{illa_num}", f"images/{illa_image}")
        if self.illa_img:
            self.illa_img = pygame.transform.smoothscale(self.illa_img, (100, 60))

        # Restablecer cuestionario
        self.question_active = False
        self.current_question = None

    # -------------------------------------------------------------
    # Eventos
    # -------------------------------------------------------------
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_e:
                if not self.question_active and self.player.rect.colliderect(self.npc.rect.inflate(40, 40)):
                    self.question_active = True
                    self.current_question = self.level_data

            if self.question_active:
                if event.key in (pygame.K_1, pygame.K_KP1):
                    self.game.check_answer(self.level_index, 0)
                elif event.key in (pygame.K_2, pygame.K_KP2):
                    self.game.check_answer(self.level_index, 1)
                elif event.key in (pygame.K_3, pygame.K_KP3):
                    self.game.check_answer(self.level_index, 2)
                elif event.key in (pygame.K_4, pygame.K_KP4):
                    self.game.check_answer(self.level_index, 3)

            if event.key == pygame.K_ESCAPE:
                self.game.go_to_start()

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.question_active:
            mx, my = event.pos
            for i, r in enumerate(self.get_options_rects()):
                if r.collidepoint((mx, my)):
                    self.game.check_answer(self.level_index, i)

    # -------------------------------------------------------------
    def update(self, dt):
        keys = pygame.key.get_pressed()
        self.player.update(dt, keys)

    # -------------------------------------------------------------
    def render(self, surf):
        # Fondo
        bg = self.assets.get("bg")
        if bg:
            surf.blit(pygame.transform.smoothscale(bg, (SCREEN_W, SCREEN_H)), (0, 0))
        else:
            surf.fill((100, 160, 110))
            pygame.draw.rect(surf, (90, 50, 20), (0, SCREEN_H - 120, SCREEN_W, 120))

        # Illa decorativa (opcional)
        if self.illa_img:
            surf.blit(self.illa_img, (SCREEN_W - 140, SCREEN_H - 180))

        # NPC y jugador
        surf.blit(self.npc.image, self.npc.rect)
        surf.blit(self.player.image, self.player.rect)

        # HUD
        self.draw_hud(surf)

        if self.message:
            msg_surf = self.bigfont.render(self.message, True, (255, 255, 255))
            surf.blit(msg_surf, msg_surf.get_rect(center=(SCREEN_W // 2, 60)))

        # Pregunta
        if self.question_active and self.current_question:
            self.draw_question_box(surf)

    # -------------------------------------------------------------
    def draw_question_box(self, surf):
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        surf.blit(overlay, (0, 0))

        box_w, box_h = 620, 300
        box = pygame.Rect((SCREEN_W - box_w) // 2, (SCREEN_H - box_h) // 2, box_w, box_h)
        box_surface = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        box_surface.fill((240, 240, 240, 230))
        pygame.draw.rect(box_surface, (40, 40, 40), box_surface.get_rect(), 3, border_radius=10)
        surf.blit(box_surface, box.topleft)

        # Texto pregunta
        question_text = self.current_question["pregunta"]
        wrapped_lines = []
        max_width = box_w - 40
        words = question_text.split()
        line = ""
        for word in words:
            test_line = f"{line} {word}".strip()
            if self.font.size(test_line)[0] > max_width:
                wrapped_lines.append(line)
                line = word
            else:
                line = test_line
        wrapped_lines.append(line)

        y_offset = box.y + 20
        for line in wrapped_lines:
            qtxt = self.font.render(line, True, (0, 0, 0))
            surf.blit(qtxt, (box.x + 20, y_offset))
            y_offset += qtxt.get_height() + 4

        # Opciones
        opts = self.current_question["opciones"]
        btn_w, btn_h = 460, 38
        btn_x = box.centerx - btn_w // 2
        btn_y = y_offset + 10
        for i, opt in enumerate(opts):
            rect = pygame.Rect(btn_x, btn_y + i * (btn_h + 10), btn_w, btn_h)
            pygame.draw.rect(surf, (220, 220, 220, 240), rect, border_radius=6)
            pygame.draw.rect(surf, (50, 50, 50), rect, 2, border_radius=6)
            label = f"{i + 1}. {opt}"
            txt = self.font.render(label, True, (0, 0, 0))
            surf.blit(txt, (rect.x + 10, rect.y + (btn_h - txt.get_height()) // 2))

        hint = self.font.render("Selecciona con 1-4 o haz clic en la opción", True, (20, 20, 20))
        surf.blit(hint, (box.centerx - hint.get_width() // 2, box.bottom - 30))

    # -------------------------------------------------------------
    def draw_hud(self, surf):
        # Corazones
        lives = self.game.lives
        for i in range(3):
            x = SCREEN_W - 20 - (i + 1) * 36
            y = 20
            color = (255, 60, 60) if i < lives else (80, 80, 80)
            pygame.draw.circle(surf, color, (x, y + 12), 12)
            pygame.draw.circle(surf, (0, 0, 0), (x, y + 12), 12, 2)

        # Illas recogidas (ahora con imagen)
        start_x, y = 16, 16
        for idx, level in enumerate(LEVELS):
            illa_key = f"illa{(idx % 15) + 1}"
            illa_img = self.game.resman.load_image(illa_key, f"images/Illa{(idx % 15) + 1}.png")
            if illa_img:
                illa_img = pygame.transform.smoothscale(illa_img, (44, 28))
                rect = pygame.Rect(start_x + idx * 50, y, 44, 28)
                surf.blit(illa_img, rect.topleft)
                if level["illa"] not in self.game.collected:
                    dim = pygame.Surface((44, 28), pygame.SRCALPHA)
                    dim.fill((0, 0, 0, 180))
                    surf.blit(dim, rect.topleft)

        # Texto nivel
        lvl_txt = self.font.render(
            f"Nivel {self.level_data['nivel']} - {self.level_data['apu']}",
            True, (255, 255, 255)
        )
        surf.blit(lvl_txt, (20, SCREEN_H - 36))



# ===========================================================
# Escena de agradecimiento tras completar el juego
# ===========================================================
class ThanksScene(SceneBase):
    def __init__(self, game):
        super().__init__(game)
        self.bg = self.game.resman.load_image("thanks_bg", "thanks_bg.png")
        self.timer = 0

    def start(self):
        self.timer = 0

    def handle_event(self, event):
        # Permite volver al menú con ESC
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.game.go_to_start()

    def update(self, dt):
        self.timer += dt
        # Después de 3 segundos, pasar automáticamente a créditos
        if self.timer > 3000:
            self.game.go_to_credits()

    def render(self, surf):
        # Muestra el fondo (o un color negro si no hay imagen)
        if self.bg:
            surf.blit(pygame.transform.smoothscale(self.bg, (SCREEN_W, SCREEN_H)), (0, 0))
        else:
            surf.fill((0, 0, 0))


# ===========================================================
# Escena final de créditos
# ===========================================================
class CreditsScene(SceneBase):
    def __init__(self, game):
        super().__init__(game)
        self.bg = self.game.resman.load_image("credits_bg", "credits_bg.png")

    def handle_event(self, event):
        # Permite volver al inicio con ESC
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.game.go_to_start()

    def render(self, surf):
        # Muestra solo el fondo de créditos
        if self.bg:
            surf.blit(pygame.transform.smoothscale(self.bg, (SCREEN_W, SCREEN_H)), (0, 0))
        else:
            surf.fill((0, 0, 0))


class GameOverScene(SceneBase):
    def __init__(self, game):
        super().__init__(game)
        # Fuente grande para el texto principal "GAME OVER"
        self.font_big = pygame.font.SysFont("Arial", 80, bold=True)
        # Fuente más pequeña para el mensaje inferior
        self.font_small = pygame.font.SysFont("Arial", 30)

        # Renderiza el texto principal en color rojo
        self.text_big = self.font_big.render("GAME OVER", True, (255, 0, 0))
        # Renderiza el texto inferior en color blanco
        self.text_small = self.font_small.render(
            "Si desea volver a intentar, presione ESC.", True, (255, 255, 255)
        )

        # Detiene cualquier música que esté sonando al entrar en la escena
        pygame.mixer.music.stop()
        
        # Reproduce el sonido de "Game Over" si está disponible
        snd = self.game.snd_gameover if hasattr(self.game, "snd_gameover") else None
        if snd:
            snd.play()

    def handle_event(self, event):
        # Si el jugador presiona la tecla ESC, se regresa al menú de inicio
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.game.go_to_start()

    def update(self, dt):
        # Esta escena no tiene animaciones ni movimiento, por eso no hace nada
        pass  

    def render(self, surf):
        # Pinta el fondo completamente negro
        surf.fill((0, 0, 0))
        w, h = surf.get_size()

        # Calcula las posiciones para centrar los textos en pantalla
        rect_big = self.text_big.get_rect(center=(w // 2, h // 2 - 50))
        rect_small = self.text_small.get_rect(center=(w // 2, h // 2 + 40))

        # Dibuja ambos textos en sus posiciones
        surf.blit(self.text_big, rect_big)
        surf.blit(self.text_small, rect_small)

# ---------- MAIN GAME ----------
class Game:
    def __init__(self):
        # Inicializa Pygame y el módulo de audio
        pygame.init()
        pygame.mixer.init()

        # Crea la ventana principal con dimensiones globales
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        pygame.display.set_caption("La búsqueda de las Illas")

        # Crea el reloj para controlar los FPS
        self.clock = pygame.time.Clock()

        # Carga el administrador de recursos (imágenes, sonidos, música, etc.)
        self.resman = ResourceManager(ASSETS_DIR)

        # Fuente por defecto del juego
        self.font = pygame.font.SysFont(FONT_NAME, 18)

        # Escena inicial: el menú principal
        self.scene = StartScene(self)

        # Variables de estado del juego
        self.running = True          # Mantiene activo el bucle principal
        self.lives = 3               # Vidas del jugador
        self.collected = set()       # Illas recolectadas
        self.current_level_scene = None

        # Inicia la música del menú principal
        self.play_music("start")
        
        # Cargar efectos de sonido
        self.snd_walk = self.resman.load_sound("walk", "walk.mp3")
        self.snd_correct = self.resman.load_sound("correct", "correct.mp3")
        self.snd_wrong = self.resman.load_sound("wrong", "wrong.mp3")
        self.snd_gameover = self.resman.load_sound("gameover", "gameover.mp3")


    # ======================================================
    # Control de música
    # ======================================================
    def play_music(self, key):
        """Reproduce la música correspondiente desde assets/music."""
        track_file = MUSIC_TRACKS.get(key)
        if not track_file:
            return
        path = MUSIC_DIR / track_file
        # Si no se encuentra, busca compatibilidad con versiones anteriores
        if not path.exists():
            path = ASSETS_DIR / track_file
        if path.exists():
            pygame.mixer.music.stop()
            pygame.mixer.music.load(str(path))
            pygame.mixer.music.play(-1)  # Reproducción en bucle
        else:
            print(f"[Aviso] No se encontró música: {track_file}")

    # ======================================================
    # Volver al menú principal
    # ======================================================
    def go_to_start(self):
        """Vuelve al menú de inicio y reinicia el estado del juego."""
        # Libera los recursos del nivel actual si existe
        if self.current_level_scene:
            self.resman.unload_level_assets(self.current_level_scene.level_data)

        # Cambia a la escena de inicio
        self.scene = StartScene(self)
        self.current_level_scene = None
        self.lives = 3
        self.collected = set()

        # Reproduce la música del menú
        self.play_music("start")

    # ======================================================
    # Iniciar un nivel específico
    # ======================================================
    def start_level(self, idx):
        """Carga y ejecuta un nivel según su índice."""
        # Si el índice supera los niveles disponibles, mostrar pantalla de agradecimiento
        if idx >= TOTAL_LEVELS:
            self.scene = ThanksScene(self)
            self.play_music("thanks")
            return

        # Si ya hay un nivel cargado, liberar sus recursos
        if self.current_level_scene:
            self.resman.unload_level_assets(self.current_level_scene.level_data)

        # Crear y asignar nueva escena del nivel
        ls = LevelScene(self, idx)
        self.current_level_scene = ls
        ls.start()
        self.scene = ls

        # 🎵 Música correspondiente al nivel
        music_key = ls.level_data.get("music", f"level{idx+1}")
        self.play_music(music_key)

    # ======================================================
    # Verificación de respuestas
    # ======================================================
    def check_answer(self, level_idx, chosen_idx):
        """Comprueba si la respuesta del jugador es correcta."""
        level = LEVELS[level_idx]
        correct = level["correct"]

        if chosen_idx == correct:
            # Respuesta correcta
            if self.snd_correct:
                self.snd_correct.play()

            # Añade la Illa conseguida
            self.collected.add(level["illa"])

            # Actualiza mensajes y estado del nivel
            self.scene.question_active = False
            self.scene.current_question = None
            self.scene.message = "¡Has conseguido la Illa!"

            # Temporizador breve antes de pasar al siguiente nivel
            pygame.time.set_timer(pygame.USEREVENT+1, 900)

        else:
            # Respuesta incorrecta: pierde una vida
            if self.snd_wrong:
                self.snd_wrong.play()

            self.lives -= 1
            self.scene.question_active = False
            self.scene.current_question = None

            if self.lives <= 0:
                # Sin vidas → escena de Game Over
                self.scene = GameOverScene(self)
            else:
                # Mostrar mensaje de error con vidas restantes
                self.scene.message = f"Respuesta incorrecta. Vidas restantes: {self.lives}"

    # ======================================================
    # Escenas finales
    # ======================================================
    def go_to_thanks(self):
        """Muestra la escena de agradecimiento final."""
        self.scene = ThanksScene(self)
        self.scene.start()

    def go_to_credits(self):
        """Muestra la escena de créditos."""
        self.scene = CreditsScene(self)

    # ======================================================
    # Bucle principal del juego
    # ======================================================
    def run(self):
        """Bucle principal del juego (eventos, actualización y renderizado)."""
        while self.running:
            dt = self.clock.tick(FPS)  # Controla la velocidad del juego (FPS)

            # --- Gestión de eventos ---
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # Cerrar el juego
                    self.running = False

                elif event.type == pygame.USEREVENT+1:
                    # Avanzar al siguiente nivel tras un acierto
                    pygame.time.set_timer(pygame.USEREVENT+1, 0)
                    current_idx = self.current_level_scene.level_index if self.current_level_scene else -1
                    next_idx = current_idx + 1
                    if len(self.collected) >= TOTAL_LEVELS:
                        self.go_to_thanks()
                    else:
                        self.start_level(next_idx)

                elif event.type == pygame.USEREVENT+2:
                    # Retornar al inicio tras Game Over
                    pygame.time.set_timer(pygame.USEREVENT+2, 0)
                    self.go_to_start()

                else:
                    # Delegar el evento a la escena actual
                    self.scene.handle_event(event)

            # --- Actualización y renderizado ---
            self.scene.update(dt)
            self.scene.render(self.screen)
            pygame.display.flip()

        # Finaliza el juego correctamente
        pygame.quit()
        sys.exit()


# ---------- EJECUCIÓN PRINCIPAL ----------
if __name__ == "__main__":
    # Asegura que existan las carpetas necesarias
    ASSETS_DIR.mkdir(exist_ok=True)
    IMAGES_DIR.mkdir(exist_ok=True)
    MUSIC_DIR.mkdir(exist_ok=True)

    # Crea e inicia el juego
    game = Game()
    game.run()
